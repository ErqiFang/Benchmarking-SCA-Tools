package org.continuous_security

/**
  * Created by nos on 2/9/17.
  */
object Main {
  def main(args: Array[String]): Unit = {
    println("Hello World!")
  }
}
