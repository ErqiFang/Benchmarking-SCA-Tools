package org.continuous_security

/**
  * Created by nos on 2/9/17.
  */
object Utils {
  def utility(args: Array[String]): Unit = {
    println("Hello World!")
  }
}
