# Scanning the test Go projects

Before scanning the Go projects available in this repository, it is advisable to copy them into your `$GOPATH/src` directory into the path `<domain>/<repository_name>/<project_name>` as it is the convention for setting up Go projects.