# War Example

This project includes a single WAR file for testing purposes.

The WAR file includes some classes and Jar files.

The 5 open-source libraries (jars) used in this project are:

1. jbcrypt-0.3m.jar
2. spring-beans-5.1.2.RELEASE.jar
3. spring-core-5.1.2.RELEASE.jar
4. spring-jcl-5.1.2.RELEASE.jar
5. spring-web-5.1.2.RELEASE.jar

