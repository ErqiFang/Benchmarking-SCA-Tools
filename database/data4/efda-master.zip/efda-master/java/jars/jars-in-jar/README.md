# Jars in Jar Example

This project includes a single Jar file for testing purposes.

The Jar file includes some classes and recursively other Jar files.

The 5 open-source libraries (jars) used in this project are:

1. jbcrypt-0.3m.jar
2. spring-beans-5.1.2.RELEASE.jar
3. spring-core-5.1.2.RELEASE.jar
4. spring-jcl-5.1.2.RELEASE.jar
5. spring-web-5.1.2.RELEASE.jar

