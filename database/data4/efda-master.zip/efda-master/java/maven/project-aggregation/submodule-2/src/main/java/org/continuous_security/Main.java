package org.continuous_security;

import org.apache.commons.fileupload.MultipartStream;

public class Main {

  public static void main(String[] args) {
    System.out.println("submodule-2 completed.");
  }
}
