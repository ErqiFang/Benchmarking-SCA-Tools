# C# Project with packages.config

This project is an example of a C# project that uses packages.config manage its
dependencies.

The 4 open-source libraries used in this project are:


1. Common.Logging version="3.4.1"
2. Common.Logging.Core version="3.4.1"
3. Microsoft.CSharp version="4.0.1"
4. YamlDotNet version="4.3.2"

Total number of dependencies:

* 4 direct dependencies.
* 0 transitive dependencies.
* 1 vulnerability.

Program.cs has a method call at line 22 - 23 that leads to a vulnerability.
